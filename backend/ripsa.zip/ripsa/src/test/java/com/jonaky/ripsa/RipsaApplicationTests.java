package com.jonaky.ripsa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RipsaApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.jonaky.ripsa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RipsaApplication {

	public static void main(String[] args) {
		SpringApplication.run(RipsaApplication.class, args);
	}

}
